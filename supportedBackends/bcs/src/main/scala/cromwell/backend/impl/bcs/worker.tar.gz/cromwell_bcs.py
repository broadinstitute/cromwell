from subprocess import Popen

import os
from simple_oss import SimpleOss, parse_bucket_object


class CromwellWorker(object):
    def __init__(self):
        self.cwd = os.environ.get("cwd")
        self.script = os.environ.get("exec")
        self.stdoutFile = os.environ.get("stdout")
        self.stderrFile = os.environ.get("stderr")

        self.ossEndpoint = os.environ.get("BATCH_COMPUTE_OSS_HOST")
        self.ossAccessId = os.environ.get("ossId")
        self.ossAccessKey = os.environ.get("ossSecret")
        self.ossSecurityToken = os.environ.get("ossToken", "")

        print self.cwd
        print self.script
        print self.stdoutFile
        print self.stderrFile
        print self.ossEndpoint
        print self.ossAccessId
        print self.ossAccessKey
        print self.ossSecurityToken

        if not self.cwd or not self.script or not self.stdoutFile or not self.stderrFile:
            raise Exception("some execution parameters is empty")

        if not self.ossAccessId or not self.ossAccessKey:
            raise Exception("some oss parameters is empty")

        self.scriptFileName = os.path.basename(self.script)
        self.localScriptName = os.path.join(self.cwd, self.scriptFileName)
        self.process = None

        self.cmd = r"""/bin/bash %s""" % self.localScriptName


        print self.scriptFileName
        print self.localScriptName
        print self.cmd

        if not os.path.exists(self.cwd):
            os.makedirs(self.cwd)

        self.stdout = open(self.stdoutFile, 'a')
        self.stderr = open(self.stderrFile, 'a')
        self.oss = SimpleOss(self.ossEndpoint, self.ossAccessId, self.ossAccessKey, self.ossSecurityToken)
        self.oss.set_verbose()

    def download_script(self):
        (bucket, obj) = parse_bucket_object(self.script)
        self.oss.download(bucket, obj, self.localScriptName)

    def clean(self):
        if not self.stdout.closed:
            self.stdout.close()
        if not self.stderr.closed:
            self.stderr.close()
	os.system("sync")


    def run(self):
        self.download_script()
        self.process = Popen(self.cmd, close_fds=False, cwd=self.cwd, shell=True, stdout=self.stdout, stderr=self.stderr)
        if self.process.wait():
            raise Exception("run error: %s" % self.process.returncode)

        self.clean()


if __name__ == '__main__':
    CromwellWorker().run()
