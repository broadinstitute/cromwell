# -*- coding: utf-8 -*-
import os
import sys
import imp
import time
import string
import base64
import logging
import traceback
import threading
import calendar
import datetime
import itertools
import httplib
import StringIO
import threading
import Queue
import datetime
import socket
import inspect
from functools import wraps

from oss import (
    oss_api, oss_xml_handler, oss_util
)


TZ, SECOND = (8, 1)
MINUTE, HOUR = (60*SECOND, 3600*SECOND)
OSS_PROTOCOL = "oss://"
# unicode only available in Python2.
STRING = (str, unicode)

RETRY_COUNT, RETRY_INTERVAL = (10, 1*SECOND)

DEFAULT_PAGE_SIZE = 500 

DEFAULT_THREAD_NUM = 10
MAX_PART_NUM = 10000
MULTI_UPLOAD_BOUND = 20 * 1024 * 1024 # 20M

def get_logger(test_name):
    log = logging.getLogger(test_name)
    log.setLevel(logging.INFO)
    hdlr = logging.FileHandler(test_name + '.LOG')
    hdlr.setLevel(logging.INFO)
    formatter = logging.Formatter("[%(asctime)s]\t[%(levelname)s]\t[%(thread)d]\t[%(pathname)s:%(lineno)d]\t%(message)s")
    hdlr.setFormatter(formatter)
    log.addHandler(hdlr)
    return log 

global_logger = get_logger('simple_oss')

def format_utf8(string):
    string = oss_util.smart_code(string)
    if isinstance(string, unicode):
        string = string.encode('utf-8')
    else:
        string = str(string)
    return string

def map_files_to_objects(bucket, local_dir, oss_prefix):
    mapped = {}
    subdirs = []
    subfiles = []
    
    if not local_dir.endswith(os.sep):
        local_dir += os.sep
    
    if not os.path.exists(local_dir) or not os.path.isdir(local_dir):
        return dict()
    
    for root, dirs, files in os.walk(local_dir):
        #for dir_name in dirs:
        #    subdirs.append(os.path.join(root, dir_name, ''))
        for file_name in files:
            subfiles.append(os.path.join(root, file_name))
    
    for path in itertools.chain(subdirs, subfiles):
        oss_object_name = os.path.join(
            OSS_PROTOCOL, bucket, oss_prefix, path[len(local_dir):]).replace('\\', '/')
        mapped[path] = oss_object_name
    
    return mapped

def map_objects_to_files(bucket, prefix, objects, local_dir):
    mapped = {}

    for (name, size, modify_time) in objects:
        object_path = os.path.join(OSS_PROTOCOL, bucket, name)
        file_path = os.path.join(local_dir, name[len(prefix):])
        mapped[object_path] = [file_path, size]

    return mapped

def parse_bucket_object(oss_path):
    if oss_path.startswith(OSS_PROTOCOL):
        oss_path = oss_path[len(OSS_PROTOCOL):]
    if not oss_path:
        return '', ''

    bucket = oss_path.split('/')[0]
    object_ = '/'.join(oss_path.split('/')[1:])

    return bucket, object_

class UploadWorker(threading.Thread):
    def __init__(self, task_queue, error_queue, upload, multiupload):
        threading.Thread.__init__(self)
        self.task_queue = task_queue
        self.error_queue = error_queue
        self.upload = upload
        self.multiupload = multiupload

    def run(self):
        while True:
            try:
                (local_path, oss_object) = self.task_queue.get(block=False)
                local_path = os.path.abspath(local_path)
                if os.path.exists(local_path) and os.path.isfile(local_path):
                    size = os.path.getsize(local_path)
                    upload_method = self.multiupload if size >= MULTI_UPLOAD_BOUND else self.upload
                    bucket, object_ = parse_bucket_object(oss_object)
                    upload_method(bucket, local_path, object_)
                self.task_queue.task_done()
            except Queue.Empty:
                break
            except:
                self.error_queue.put(
                    'Failed to upload %s, exc_info: %s' % (local_path, sys.exc_info()[2]))
                self.task_queue.task_done()

class DownloadWorker(threading.Thread):
    def __init__(self, task_queue, error_queue, download, multidownload):
        threading.Thread.__init__(self)
        self.task_queue = task_queue
        self.error_queue = error_queue
        self.download = download 
        self.multidownload = multidownload 

    def run(self):
        while True:
            try:
                (oss_object, file_info) = self.task_queue.get(block=False)
                local_path = os.path.abspath(file_info[0])
                size = file_info[1]
                
                if oss_object.endswith('/'): 
                    # objects end with '/' is special.
                    if size == 0:
                        # Only make the directory if size is 0.
                        os.makedirs(local_path)
                    else:
                        # Ignore object if size is not 0/
                        pass

                    self.task_queue.task_done()
                    continue

                download_method = self.multidownload if size >= MULTI_UPLOAD_BOUND else self.download
                bucket, object_ = parse_bucket_object(oss_object)

                dirname = os.path.dirname(local_path)
                filename = os.path.basename(local_path)
                if filename and dirname:
                    if not os.path.exists(dirname) or not os.path.isdir(dirname):
                        os.makedirs(dirname)
                    download_method(bucket, object_, local_path)
                self.task_queue.task_done()
            except Queue.Empty:
                break
            except:
                self.error_queue.put(
                    'Failed to download %s, exc_info: %s' % (oss_object, sys.exc_info()[2]))
                self.task_queue.task_done()

class OssError(Exception):
    def __init__(self, status, code, err_info, res):
        super(OssError, self).__init__(self)
        self.st = status
        self.code = code
        self.err = err_info 
        self.res = res

    def __str__(self):
        return 'status: %s code: %s, message: %s' % (
            self.get_status(), self.get_code(), self.get_msg())

    def get_status(self):
        return self.st
    
    def get_code(self):
        return self.code

    def get_msg(self):
        return self.err

class OssUnretryError(OssError):
    def __init__(self, status, code, err_info, res):
        self.st = status 
        self.code = code
        self.err = err_info 
        self.res = res
        super(OssUnretryError, self).__init__(self.st, self.code, self.err, self.res)
        
class ObjectNotExists(OssUnretryError):
    def __init__(self, status, code, err_info, res):
        self.st = status 
        self.code = code 
        self.err = err_info 
        self.res = res
        super(ObjectNotExists, self).__init__(self.st, self.code, self.err, self.res)

class InvalidBucket(OssUnretryError):
    def __init__(self, code='AccessDenied'):
        self.st = 403 
        self.code = code 
        self.err = 'Bucket is unaccessable' 
        super(InvalidBucket, self).__init__(self.st, self.code, self.err, None)

def oss_to_epoch(timestamp):
    # given a time string like: 2014-05-15T11:18:32.000Z
    # convert it to an epoch time.
    imp.acquire_lock()
    ts = datetime.datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S.000Z").timetuple()
    imp.release_lock()
    return (int)(time.mktime(ts)) 

def gmt_to_epoch(gmtT):
    return (int)(calendar.timegm(time.strptime(gmtT, "%a, %d %b %Y %H:%M:%S GMT")))

class CheckWrapper(object):
    def __init__(self):
        pass

    def __call__(self, func):
        @wraps(func)
        def wrapper(*args, **kwargs): 
            response = func(*args, **kwargs)
            res = self.do_check(response)
            return res 
        return wrapper

    def do_check(self, http_response):
        data, status = http_response.read(), http_response.status
        if status/100 == 2:
            error = None 
        elif status == 403:
            error = oss_xml_handler.ErrorXml(data)
            raise OssUnretryError(403, error.code, error.msg, http_response)
        elif status == 404:
            error = oss_xml_handler.ErrorXml(data)  
            raise ObjectNotExists(404, error.code, error.msg, http_response)
        else:
            try:
                error = oss_xml_handler.ErrorXml(data)
            except Exception, e:
                raise OssError(status, "Internal Server Error", data, http_response)
            else:
                raise OssError(status, error.code, error.msg, http_response)
        return ResponseProxy(http_response, data, error)

class RetryWrapper(object):
    def __init__(self, verbose):
        self.verbose = verbose
        self.retry, self.interval = (RETRY_COUNT, RETRY_INTERVAL)
        
    def __call__(self, func):

        def _args_to_utf8(func, args, kwargs):
            '''Convert func's argsments to utf-8 to satisfy the encoding rules
            of oss object names, arguments named `file` or `dir`, however, are
            native encoded file or directory names, no need be converted to utf-8.
            '''

            ignores = ['file', 'dir']
            args_info = inspect.getargspec(func)
            names = args_info.args
            ignore_indexs = [names.index(ignore) for ignore in ignores if ignore in names]

            utf8_args = []
            for index, arg in enumerate(args):
                if arg and isinstance(arg, STRING) and not index in ignore_indexs:
                    utf8_args.append(format_utf8(arg))
                else:
                    utf8_args.append(arg)

            utf8_kwargs = {}
            for name, value in kwargs.items():
                if value and isinstance(value, STRING) and name not in ignores:
                    utf8_kwargs[name] = format_utf8(value)
                else:
                    utf8_kwargs[name] = value

            return utf8_args, utf8_kwargs

        @wraps(func)
        def wrapper(*args, **kwargs):
            error = None
            fatal = False
            status_prompt = 'Try to '
            prompt = '''calling %s(args=%s, kwargs=%s) '''%(func.__name__, args[1:], kwargs)
            for retried in range(self.retry):
                try:
                    if error: time.sleep(self.interval)
                    utf8_args, utf8_kwargs = _args_to_utf8(func, args, kwargs)
                            
                    result = func(*utf8_args, **utf8_kwargs)
                except OssUnretryError, e:
                    error = e 
                    fatal = True
                except OssError, e:
                    error = e
                    fatal = False
                except socket.error, e:
                    error = e
                    fatal = False
                except Exception, e:
                    error = e
                    fatal = True 
                else:
                    error = None
                finally:
                    if error and not fatal: 
                        if self.verbose:
                            status_prompt = 'Failed to '
                            error_info = self.extract_tb() 
                            global_logger.exception(status_prompt + prompt + error_info + ' But Retry')
                    elif error and fatal:
                        if self.verbose:
                            status_prompt = 'Failed to '
                            error_info = self.extract_tb() 
                            global_logger.exception(status_prompt + prompt + error_info + ' Not Retry')
                        raise error
                    else:
                        if self.verbose:
                            status_prompt = 'Successed to '
                            global_logger.info(status_prompt + prompt)
                        return result
            else:
                if error: raise error
        return wrapper

    def set_verbose(self):
        self.verbose = True 

    def clear_verbose(self):
        slef.verbose = False

    def set_retry(self, retry, interval):
        self.retry, self.interval = (retry, interval)

    def extract_tb(self):
        stack = [] 
        _, _, exc_tb = sys.exc_info()

        if exc_tb:
            for filename, linenum, funcname, source in traceback.extract_tb(exc_tb):
                stack.append("TRACEINFO: %-23s:%s '%s' in %s()" % (filename, linenum, source, funcname))

        return '\n'.join(stack)


class OssAPIProxy(object):
    def __init__(self, host, id, key, sts_token=None, is_security=False):
        port = 443 if is_security else 80

        self.oss = oss_api.OssAPI(host, id, key,
                                  port=port,
                                  sts_token=sts_token,
                                  is_security=is_security)
        self.check_wrapper = CheckWrapper() 

    def __getattr__(self, attr):
        if attr == 'head_object':
            origin_method = self.head_object
        else:
            origin_method = getattr(self.oss, attr)
        return self.check_wrapper(origin_method)

    def head_object(self, bucket, path):
        h = {'Range': 'bytes=0-0'}
        response = self.oss.head_object(bucket, path)
        body = self.get_object(bucket, path, headers=h)
        return ResponseProxy(response, body.read()) 

class ResponseProxy(object):
    def __init__(self, response, data, error=None):
        self.response = response
        self.error = error
        self.data = StringIO.StringIO()
        self.data.write(data)
        self.data.seek(0)

    def __getattr__(self, attr):
        if attr == 'read':
            return self.data.read
        else:
            return getattr(self.response, attr)

class MetaClass(type):
    def __new__(cls, nm, parents, attrs):
        super_new = super(MetaClass, cls).__new__
        retry_wrapper = RetryWrapper(attrs.get('verbose'))
        for key, value in attrs.iteritems():
            if callable(value) and not key.startswith('__') and key != '_check_bucket':
                attrs[key] = retry_wrapper(value)
            else:
                pass
        attrs['retry_wrapper'] = retry_wrapper
        return super_new(cls, nm, parents, attrs)

class SimpleOss(object):
    '''A wrapper class to make enjoy oss easy.

    NOTICE: To avoid the conversion to utf-8 of local file names and local dir
    names, the argument name of local file name and local dir name was limited
    to `file` and `dir` respectively, e.g:

    def upload(self, bucket, file, object_)

    def upload_dir(self, bucket, dir, object_)

    '''

    __metaclass__ = MetaClass
    verbose = False

    def __init__(self, *args, **kwargs):
        meta_keys = ['host', 'id', 'key']
        metas = list(map(kwargs.get, meta_keys))
        if None in metas:
            metas = list(args[:3])

        sts_token = kwargs.get("sts_token", None)
        if not sts_token and len(args) >= 4:
            sts_token = args[3]
        is_security = kwargs.get("is_security", False)
        if not is_security and len(args) >= 5:
            is_security = args[4]

        metas.append(sts_token)
        metas.append(is_security)
        self.clnt = OssAPIProxy(*metas)

    def set_verbose(self):
        self.retry_wrapper.set_verbose()

    def clear_verbose(self):
        self.retry_wrapper.clear_verbose()

    def set_retry(self, retry, interval):
        self.retry_wrapper.set_retry(retry, interval)

    def _check_bucket(self, bucket_name):
        bucket_error_codes = [
            'NoSuchBucket',
            'InvalidBucketName',
            'AccessDenied',
        ]

        if bucket_name:
            try:
                subpath = ''
                next_marker = ''
                delimiter = ''
                maxkeys = 1
                _ = self.clnt.get_bucket(bucket_name, subpath, 
                        next_marker, delimiter, maxkeys).read()
                print "haha"
            except OssError, e:
                print e
                if e.get_code() in bucket_error_codes: 
                    raise InvalidBucket(e.get_code())
                else:
                    raise e
        else:   
            raise InvalidBucket('''Bucket name can't be empty string''')

    def list(self, bucket, path, delimiter='', verbose=False):
        self._check_bucket(bucket)

        page_size = DEFAULT_PAGE_SIZE 
        xml_hdlr = oss_xml_handler 
        def next_page():
            next_marker = ''
            is_truncated = True
            while is_truncated:
                res = self.clnt.get_bucket(bucket, path, 
                            next_marker, delimiter, page_size)
                parsed_xml = xml_hdlr.GetBucketXml(res.read())
                entry_list = parsed_xml.content_list
                prefix_list = parsed_xml.prefix_list
                for entry in itertools.chain(prefix_list, entry_list):
                    if isinstance(entry, STRING):
                        yield format_utf8(entry)
                    else:
                        yield (entry.key, entry.size, oss_to_epoch(entry.last_modified)) if verbose else format_utf8(entry.key)
                else:
                    is_truncated = parsed_xml.is_truncated
                    next_marker = parsed_xml.nextmarker 
        l = [entry for entry in next_page()]
        return l

    def upload(self, bucket, file, object_):
        self._check_bucket(bucket)

        op = os.path
        if op.isdir(file):
            file = op.join(file, op.basename(object_))
        res = self.clnt.put_object_from_file(bucket, object_, file)
        return not res.error 

    def upload_dir(self, bucket, dir, object_):
        self._check_bucket(bucket)
        
        allFiles = []
        for d, dirs, files in os.walk(dir):
            for f in files:
                allFiles.append(os.path.join(d, f))

        for f in allFiles:
            if dir.endswith(os.sep):
                objPath = f[len(dir):]
            else:
                objPath = f[len(dir) + 1:]
            f = f.replace('\\', '/')
            abObj = os.path.join(object_, objPath).replace('\\', '/')
            res = self.upload(bucket, f, abObj)
            if not res:
                return False
        return True

    def download(self, bucket, object_, file):
        self._check_bucket(bucket)

        op = os.path
        if op.isdir(file):
            file = op.join(file, op.basename(object_))
        res = self.clnt.get_object_to_file(bucket, object_, file)
        return not res.error 

    def delete(self, bucket, path):
        self._check_bucket(bucket)

        if self.isdir(bucket, path):
            path = path + '/' if  not path.endswith('/') else path
            for object_ in self.list(bucket, path):
                if object_.startswith(path):
                    self.clnt.delete_object(bucket, object_)
        else:
            self.clnt.delete_object(bucket, path)
        return True

    def exists(self, bucket, path):
        '''
        try:
            self._check_bucket(bucket)
        except InvalidBucket, e:
            return False
        '''

        print "1"
        
        if not path:
            return True

        if path.endswith('/'):
            res = self.clnt.get_bucket(bucket, path)
            parsed_xml = oss_xml_handler.GetBucketXml(res.read())
            return True if parsed_xml.content_list else False
        else:
            try:
                res = self.clnt.head_object(bucket, path)
                return True
            except ObjectNotExists, e:
                return False
    
    def isdir(self, bucket, path):
        self._check_bucket(bucket)

        if path and not path.endswith('/'):
            path += '/'
        if self.exists(bucket, path):
            next_marker = ''
            delimiter = ''
            page_size = 1 
            res = self.clnt.get_bucket(bucket, path, 
                                next_marker, delimiter, page_size)
            parsed_xml = oss_xml_handler.GetBucketXml(res.read())
            if parsed_xml.is_truncated or len(parsed_xml.content_list)>=1:
                return True 
            else:
                return False
        else:
            return False

    def download_str(self, bucket, path):
        self._check_bucket(bucket)

        res = self.clnt.get_object(bucket, path)
        return res.read() 

    def upload_str(self, bucket, string, path):
        self._check_bucket(bucket)

        res = self.clnt.put_object_from_string(bucket, path, string)
        return not res.error 

    def list_bucket(self, verbose=False):
        res = self.clnt.list_all_my_buckets()
        parsed_xml = oss_xml_handler.GetServiceXml(res.read())
        buckets = [bkt_info if verbose else bkt_info[0] for bkt_info in parsed_xml.list()]
        return buckets

    def len(self, bucket, path):
        self._check_bucket(bucket)

        len, _, _ = self.stat(bucket, path)
        return len

    def stat(self, bucket, path):
        self._check_bucket(bucket)

        res = self.clnt.head_object(bucket, path)
        len = int(res.getheader('content-length'))
        etag = res.getheader('etag')
        mtime = gmt_to_epoch(res.getheader('last-modified'))
        return len, etag, mtime 

    def multi_get(self, bucket, object_, file, thread=DEFAULT_THREAD_NUM):
        self._check_bucket(bucket)

        if file.endswith('/'):
            file = os.path.join(file, os.path.basename(object_))
        return oss_util.multi_get(self.clnt, bucket, 
                object_, file, thread, RETRY_COUNT)

    def multi_put(self, bucket, file, object_, thread=DEFAULT_THREAD_NUM):
        self._check_bucket(bucket)

        id, part_num, h = ('', MAX_PART_NUM, {})
        res = self.clnt.multi_upload_file(bucket, object_, file, 
                id, thread, part_num, h)
        return not res.error

    def append_str(self, bucket, string, path, position):
        self._check_bucket(bucket)
        global_logger.info('SimpleOss: append_str, Position: ' + format_utf8(position) + ', Bucket: ' + bucket)
        
        try:
            res = self.clnt.append_object_from_string(bucket, path, position, string)
            return (not res.error), int(res.getheader('x-oss-next-append-position'))
        except OssError, e:
            global_logger.exception('SimpleOss: append_str, AppendError: ')
            if e.code == 'PositionNotEqualToLength' and e.st == 409:
                return False, int(e.res.getheader('x-oss-next-append-position'))
            raise

    def multi_upload_all(self, files, threadnum=DEFAULT_THREAD_NUM):
        '''Upload all files in `files` to oss.

        @param `files`: all files
        @type `files`: a {dict} object, `key` is the file path, and `value` is
            the object name the file will be stored in oss.
        '''

        assert isinstance(files, dict) and threadnum > 0 and threadnum < 20, \
            'files must be dict type, 0< threadnum < 20'

        task_queue = Queue.Queue(0)
        error_queue = Queue.Queue(0)
        for (file, object_) in files.items():
            task_queue.put((file, object_))
        size = task_queue.qsize()

        if size < threadnum:
            threadnum = size

        thread_pool = []
        for threadnum in xrange(threadnum):
            current = UploadWorker(task_queue, error_queue, self.upload, self.multi_put)
            thread_pool.append(current)
            current.start()
        task_queue.join()
        for thread in thread_pool:
            thread.join()

        errs = []
        while True:
            try:
                error = error_queue.get(block=False)
                errs.append(error)
            except Queue.Empty:
                break

        return size, errs

    def multi_upload_dir(self, bucket, local_dir, oss_prefix, threadnum=DEFAULT_THREAD_NUM):
        all_files = map_files_to_objects(bucket, local_dir, oss_prefix)

        return self.multi_upload_all(all_files, threadnum)

    def multi_download_all(self, objects, threadnum=DEFAULT_THREAD_NUM):
        '''Download all objects in 'objects' to local directory.

        @param `files`: all files
        @type `files`: a {dict} object, `key` is the file path, and `value` is
            the object name the file will be stored in oss.
        '''

        assert isinstance(objects, dict) and threadnum > 0 and threadnum < 20, \
            'objects must be dict type, 0< threadnum < 20'

        task_queue = Queue.Queue(0)
        error_queue = Queue.Queue(0)
        for (object_, file_info) in objects.items():
            task_queue.put((object_, file_info))
        size = task_queue.qsize()

        if size < threadnum:
            threadnum = size

        thread_pool = []
        for threadnum in xrange(threadnum):
            current = DownloadWorker(task_queue, error_queue, self.download, self.multi_get)
            thread_pool.append(current)
            current.start()
        task_queue.join()
        for thread in thread_pool:
            thread.join()

        errs = []
        while True:
            try:
                error = error_queue.get(block=False)
                errs.append(error)
            except Queue.Empty:
                break

        return size, errs

    def multi_download_dir(self, bucket, oss_prefix, local_dir, threadnum=DEFAULT_THREAD_NUM):
        self._check_bucket(bucket)
        if not oss_prefix.endswith('/'):
            raise Exception('oss_prefix must end with /.')

        all_objects = self.list(bucket, oss_prefix, verbose=True)
        all_objects = map_objects_to_files(bucket, oss_prefix, all_objects, local_dir)

        return self.multi_download_all(all_objects, threadnum)

if __name__ == "__main__":
    print "hjaha"
    host = "oss-cn-beijing-internal.aliyuncs.com"
    id = "uXz2Ru6DcbBxUz3v"
    key = "xYeWO8vPAtIH4NmtEFe7zfH27aeJSD"
    token = ""
    oss = SimpleOss(host, id, key, token)
    oss.set_verbose()
    for i in range(1000*1000):
        bucket, obj = parse_bucket_object("oss://diku-debug-beijing/package.tar.gz")
        print oss.exists(bucket, obj)
